from fastapi import BackgroundTasks,APIRouter,Depends,status, Request,HTTPException,Form,status,File,UploadFile
from sqlalchemy.orm import session
from fastapi import FastAPI,Depends,status,HTTPException,Query
from sqlalchemy.orm import session
from pydantic import BaseModel
from fastapi.responses import JSONResponse,StreamingResponse
from pydantic import BaseModel

#models impors
from models.users import  User
from  models import Session

#single imports
import os,pytz,logging,io
from typing import List,Optional,Annotated
from datetime import datetime

#other imports
from .auth  import get_current_user
import utilities.logger as Logger
from infra.utils import send_notifications
from routers.auth import get_password_hash,get_current_username
from infra.email_templates import get_notify_template

class ResetPasswordRequest(BaseModel):
    email: str
    otp: str
    new_password: str

error_logger = Logger.get_logger('error', logging.ERROR)
info_logger = Logger.get_logger('info', logging.INFO)

# models.Base.metadata.create_all(bind=engine)


router = APIRouter(
    prefix="/users",
    tags=["Users"],
    responses={401: {"user": "Not authorized"}}
)

def get_db():
    try:
        db = Session()
        yield db
    finally:
        db.close()

@router.get("/")
async def logined_user(db: session = Depends(get_db),user: dict = Depends(get_current_user)):

    try:

        if user is None:
            return {"message":"user not found", "status":status.HTTP_404_NOT_FOUND }

        info_logger.info(f"user with email {user.get('email')} has accessed the get_logined_user API")
        db_user = db.query(User).filter(User.is_active == True, User.id == user.get("user_id")).first()

        info_logger.info(f'Successfully fetched user details from database')
        return {"message": "successful",
                "data":{
                "user_details":db_user
                },
                "status":status.HTTP_200_OK }

    except Exception as error:
        error_logger.exception(f"Error occurred in get_logined_user API.Error:{error}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,detail=str(error))

    finally:
        if db:
            db.close()

@router.post("/add_phone_number")
def add_phone_number(user: Annotated[str, Depends(get_current_username)],user_id:int,phone_number:str,db: session = Depends(get_db)):
    try:

        db_user = db.query(User).filter(User.is_active == True,User.id == user_id).first()

        if not db_user:
            return JSONResponse({"detail":"INVALID USER ID"},status_code=404)

        info_logger.info(f"user with email {db_user.email} has accessed the add_phone_number API")

        db_user.phone_number = phone_number
        db.commit()

        info_logger.info(f"user successfully added phone_number")
        return {"message":"user successfully added phone_number","status_code":200}

    except Exception as e:
        error_logger.error(f"Error occurred while adding phone_number  error= {e}")
        return JSONResponse({"detail":str(e)},status_code=500)
    finally:
        if db:
            db.close()


@router.delete("/delete_user")
async def delete_user(db: session = Depends(get_db),user:dict = Depends(get_current_user)):
    try:

        if user is None:
            return JSONResponse({"detail":"NOT AUTHENTICATED"},status_code=401)

        info_logger.info("user with email accessed /delete_user API")

        db_user = db.query(User).filter(User.is_active == True,User.id == user.get('user_id')).first()
        user_id = user.get('user_id')
        db_user.is_active = False

        username = db_user.username
        email = db_user.email


        info1 = "We have successfully processed your request to deactivate your account with Maang Buy Rent Exchange. Your account is now inactive, and you will not be able to log in or access our services until you reactivate your account."
        info2 = "Thank you for being a part of Maang Buy Rent Exchange. If you have any questions or need assistance, feel free to reach out to our support team"
        html_content = get_notify_template(username,info1,info2)

        subject = "Your Account Has Been Deactivated!"

        await send_notifications(email, subject, html_content)

        db.commit()
        
        info_logger.info("user successfully deactivated his account")
        return {"detail":"USER SUCESSFULLY DEACTIVATED HIS ACCOUNT","status_code":204}

    except Exception as e:
        error_logger.error(f"Error occurred while deleting user error= {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@router.put("/activate_existed_account")
async def activate_existed_account(user: Annotated[str, Depends(get_current_username)],email_or_phone:str,db: session = Depends(get_db)):
    try:


        db_user = db.query(User).filter((User.email == email_or_phone) | (User.phone_number == email_or_phone)).first()

        if not db_user :
            return JSONResponse({"detail":"INVALID EMAIL,EMAIL DOES NOT REGISTERED "},status_code=400)

        if db_user.is_active == True:
            return JSONResponse({"detail":"INVALID REQUEST ,THE ACCOUNT IS ALREADY  ACTIVE "})

        info_logger.info(f"user with email_or_phone {email_or_phone} has accessed the /activate_existed_account API")

        user_id = db_user.id
        db_user.is_active = True
        db.commit()

        info1 = "Welcome back to Maang Buy Rent Exchange! We are happy to inform you that your account has been successfully reactivated. You can now log in and access all the features and services once again."
        info2 = "Thank you for continuing your journey with Maang Buy Rent Exchange!. If you have any questions or need assistance, feel free to reach out to our support team"
        html_content = get_notify_template(db_user.username,info1,info2)

        subject = "Welcome Back! Your Account Has Been Reactivated"

        await send_notifications(db_user.email, subject, html_content)

        info_logger.info(f"successfully activate his account  user_email_or_phone:{email_or_phone}")
        return {"message":"USER ACTIVATED HIS ACCOUNT SUCESSFULLY","status_code":204}

    except Exception as e:
        error_logger.error(f"Error occurred in  /activate_existed_account_API error= {e}")
        raise HTTPException(status_code=500,detail=str(e))
    finally:
        if db:
            db.close()
