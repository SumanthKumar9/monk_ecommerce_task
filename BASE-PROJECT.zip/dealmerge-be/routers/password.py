#fastapi
from fastapi import APIRouter,Depends,status, Request,HTTPException,status
from sqlalchemy.orm import session
from fastapi import FastAPI,Depends,status,HTTPException,Query
from pydantic import BaseModel
from fastapi.responses import JSONResponse

#models
from models.users import  User
from  models import Session
from .auth  import get_current_user,verify_password
from typing import List,Optional,Annotated
from models.otp_counters import OtpCounters

#single imports
from datetime import datetime,timedelta
import os,pytz,logging,random,string,requests

import utilities.logger as Logger
from infra.utils import send_notifications
from routers.auth import get_password_hash,get_current_username

from infra.notifications import notification_for_password_reset,notification_for_password_change
from infra.email_templates import get_otp_template
from utilities.constants import DEV_API_URL


class ResetPasswordRequest(BaseModel):
    otp: str
    new_password: str

class ChangePasswordRequest(BaseModel):
    email: str
    current_password: str
    new_password: str

error_logger = Logger.get_logger('error', logging.ERROR)
info_logger = Logger.get_logger('info', logging.INFO)

# models.Base.metadata.create_all(bind=engine)


router = APIRouter(
    prefix="/password",
    tags=["Password"],
    responses={401: {"user": "Not authorized"}}
)

def get_db():
    try:
        db = Session()
        yield db
    finally:
        db.close()

@router.post("/forgot-password")
async def forgot_password(user: Annotated[str, Depends(get_current_username)],db: Session = Depends(get_db),email: Optional[str] = None,phone_number: Optional[str] = None):

    try:

        if not email and not phone_number:
            return JSONResponse({"detail":"EITHER phone_number OR email MUST BE ASSIGNED"},status_code=403)

        if email and phone_number:
            return JSONResponse({"detail":"ONLY EITHER phone_number OR email CAN BE ASSIGNED"},status_code=403)


        if email:
            user = db.query(User).filter(User.is_active == True, User.email == email).first()
        else:
            user = db.query(User).filter(User.is_active == True, User.phone_number == phone_number).first()
            print(user)

        if not user:
            return JSONResponse({"detail":"User not found"},status_code=404)

        print(user)
        info_logger.info(f"User with email {user.email} requested for password reset")

        # Generate a random OTP
        otp = "".join(random.choices(string.digits, k=4))
        user.otp = otp
        print(otp)
        user.otp_expires = datetime.now() + timedelta(minutes=5)
        db.commit()

        if email:
            # Send the OTP to the user via email
            otp_info = "You requested for a password reset"
            otp_purpose = "reset password"
            html_content = get_otp_template(user.username,otp,otp_purpose,otp_info)

            # Send the OTP to the user via email
            subject = "OTP for Reset Password"

            await send_notifications(email, subject, html_content)

            info_logger.info(f"sent password reset otp successfully to user with user email:{email}")

        elif phone_number:

            info_logger.info(f"User with phone_number {phone_number} requested for forgot password otp")
            user = db.query(OtpCounters).filter(OtpCounters.phone_number == phone_number).first()
            if user:
                if user.forgot_password_otp_count >= 3:
                    return JSONResponse({"detail":"YOU HAVE REACHED MAXIMUM OTP LIMIT ,TRY AFTER SOMETIME OR TRY USING WITH EMAIL"},status_code=400)
                else:

                    params = {
                            "authorization": "WKUeIZgvEtP5iRClmL8upnNyj70dO3Y6V1f2QhSXTHzasoJkbcx7WTCLtmglkbaidHq0hNPsQVO45U6M",
                            "route": "dlt",
                            "sender_id": "MAANG",
                            "variables_values" : f"Deal Merge|{otp}|",
                            "message": "173105",
                            "numbers": f"{phone_number}",
                            "flash": "0"
                    }

                    response = requests.get(DEV_API_URL, params=params)

                    if response.status_code != 200:
                        return JSONResponse({"detail":f"SENDING SMS FAILED : {response.text}"},status_code= response.status_code)

                    user.forgot_password_otp_count += 1
                    user.forgot_password_latest_otp_requested_date  = datetime.now()
                    db.commit()

            else:
                params = {
                        "authorization": "WKUeIZgvEtP5iRClmL8upnNyj70dO3Y6V1f2QhSXTHzasoJkbcx7WTCLtmglkbaidHq0hNPsQVO45U6M",
                        "route": "dlt",
                        "sender_id": "MAANG",
                        "variables_values" : f"Deal Merge|{otp}|",
                        "message": "173105",
                        "numbers": f"{phone_number}",
                        "flash": "0"
                }

                response = requests.get(DEV_API_URL, params=params)

                if response.status_code != 200:
                    return JSONResponse({"detail":f"SENDING SMS FAILED : {response.text}"},status_code= response.status_code)

                user_model = OtpCounters(
                    phone_number = phone_number,
                    forgot_password_latest_otp_requested_date = datetime.now(),
                    created_by = phone_number,
                    forgot_password_otp_count = 1
                )
                db.add(user_model)
                db.commit()


            info_logger.info(f"sent password reset otp successfully to user with user email:{email}")

        return {"message": f"OTP sent to your {'email' if email else 'phone_number'}. Use it to reset your password."}

    except Exception as error:

        error_logger.error(f"Error occurred in /forgot-password API while generating OTP for user with email {email}: {str(error)}")
        raise HTTPException(status_code=500, detail=str(error))
    finally:
        if db:
            db.close()

@router.post("/reset_password")
async def reset_password(user: Annotated[str, Depends(get_current_username)],request:ResetPasswordRequest,db: Session = Depends(get_db),email: Optional[str] = None,phone_number: Optional[str] = None):

    try:

        if not email and not phone_number:
            return JSONResponse({"detail":"EITHER phone_number OR email MUST BE ASSIGNED"},status_code=403)

        if email and phone_number:
            return JSONResponse({"detail":"ONLY EITHER phone_number OR email CAN BE ASSIGNED"},status_code=403)

        if email:
            user = db.query(User).filter( User.is_active == True, User.email == email).first()
        else:
            user = db.query(User).filter(User.is_active == True, User.phone_number == phone_number).first()

        if not user:
            return JSONResponse({"detail":"User not found"},status_code=404)

        info_logger.info(f"User with email {user.email} requested for password reset")

        if user.otp != request.otp :
            return JSONResponse({'detail':"Invalid  OTP"},status_code=400)

        if datetime.now() > user.otp_expires:
            return JSONResponse({'detail':"OTP is Expired"},status_code=400)

        user.password = get_password_hash(request.new_password)
        user.otp = None
        user.otp_expires = None
        db.add(user)
        db.commit()

        info_logger.info(f"User with email :{user.email} has successfully reset the password")
        await notification_for_password_reset(user.email,user.username)

        return {"message": "Password reset successful"}

    except Exception as error:

        error_logger.error(f"Error occurred in reset_password API while reseting password for user with email {request.email}: {str(error)}")
        return JSONResponse({"detail":str(error)},status_code =500)

    finally:
        if db:
            db.close()

@router.post("/change_password")
async def change_password(user: Annotated[str, Depends(get_current_username)],request: ChangePasswordRequest, db: Session = Depends(get_db)):
    info_logger.info(f"Password change request received for email: {request.email}")
    try:
        user = db.query(User).filter(User.is_active == True, User.email == request.email).first()

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if not verify_password(request.current_password, user.password):
            return JSONResponse({"detail":"Incorrect current password"})

        user.password = get_password_hash(request.new_password)
        db.commit()
        db.refresh(user)

        await notification_for_password_change(request.email,user.username)
        info_logger.info(f"Password changed successfully for email: {request.email}")
        return {"message": "Password changed successfully"}

    except Exception as e:
        error_logger.exception("An unexpected error occurred during password change")
        raise HTTPException(status_code=500, detail="An unexpected error occurred")

    finally:
        if db:
            db.close()
