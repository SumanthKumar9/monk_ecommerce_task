#fastapi imports
from fastapi import Response, status, Depends, APIRouter,Security
from starlette.requests import Request
from starlette.responses import JSONResponse
from pydantic import BaseModel,EmailStr
from datetime import datetime

#single imports
from typing import Optional,Annotated
import logging

#models imports
from models import Session
from models.users import User
from models.user_activity import UserActivity

#otherimports
from apps.validator import  auth
import utilities.logger as Logger
from routers.auth import get_password_hash,get_current_username


error_logger = Logger.get_logger('error', logging.ERROR)
info_logger = Logger.get_logger('info', logging.INFO)

router = APIRouter(prefix='/auth',tags=["Auth"])

class UpdateStatus(BaseModel):
    status: bool

class UserUpdate(BaseModel):
    status: bool
    access: str

class user(BaseModel):
    email: EmailStr
    name: str
    oauth_token: str

class access(BaseModel):
    email: EmailStr
    name: str
    access: str

def is_deactivated_account_exists(email):
    db = Session()
    # Check if user exists
    db_user = db.query(User).filter(User.email == email).first()

    if db_user and db_user.is_active == False:
        return True

    return None

def is_phone_number_exists(user_id):
    session = Session()
    db_user = session.query(User).filter(User.is_active == True,User.id == user_id).first()

    if  db_user:
        if db_user.phone_number:
            return True
        return False

def get_users(email):
    session = None
    try:
        session = Session()
        result_set = session.query(User).filter(User.is_active == True,User.email == email)
        result_set_count = result_set.count()
        result_set = result_set.all()
        if result_set_count > 0:
            for db_ in result_set:
                if db_.access == 'super':
                    return True
                else:
                    return False
        else:
            return None
    except Exception as err:
        return None
    finally:
        if session:
            session.close()

@router.post("/social-login")
async def create_user(auth_user: Annotated[str, Depends(get_current_username)],request_context: Request, user: user, response: Response):

    session = None
    try:
        session = Session()
        email = user.email

        if is_deactivated_account_exists(email):
            return {"is_deactivated":True}

        name = user.name
        oauth_token = user.oauth_token
        access = "normal"
        data = auth.login_user(email, name, oauth_token)
        # image = data['data']["user_details"]["picture"]
        user_id = 0

        if data.get("status_code") == 200:
            result_set = session.query(User).filter(User.is_active == True,User.email == email)
            result_set_count = result_set.count()
            result_set = result_set.all()
            if result_set_count == 0:
                db_ = User(email=email,username=name)
                session.add(db_)
                session.commit()
                session.refresh(db_)
                response.status_code = status.HTTP_201_CREATED
                info_logger.info(f'User added: {email}')
                user_activity_model = UserActivity(
                    user_id = db_.id,
                    created_by = db_.email,
                    login_success_count = 1,
                    last_successful_login = str(datetime.now())
                )
                session.add(user_activity_model)
                session.commit()
                user_id = db_.id
            else:
                user_id = result_set[0].id
                user_activity = session.query(UserActivity).filter(UserActivity.is_active == True,UserActivity.user_id == result_set[0].id).first()
                if user_activity:
                    user_activity.login_success_count += 1
                    user_activity.last_successful_login = str(datetime.now())
                    session.commit()
                access = get_users(email)

        data["admin"] = access
        data["data"]["user_id"] = user_id
        data["data"]["is_phone_number_exists"] = is_phone_number_exists(user_id)
        return data
    except Exception as err:
        error_logger.exception(f'Exception occured in create_user. Error: {err}')
        return JSONResponse({"error_code": "create_user_api_failed",
                             "message": "Technical Error occurred while storing the create_user"}, status_code=500)
    finally:
        if session:
            session.close()
