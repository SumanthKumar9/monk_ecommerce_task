import os
from urllib.parse import quote

GOOGLE_CLIENT_ID="342487029539-9amlsnhpp3e24grhpouju8vnl1taooei.apps.googleusercontent.com"
ALLOWED_DOMAINS = [
    "*",
    "maangtechnologies.com",
    "gmail.com"
]
JWT_ENCODING_ALGORITHM = 'HS256'
JWT_EXPIRY_WINDOW_IN_HOURS = 24
#JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY')
JWT_SECRET_KEY = "MhvR7A0r9MObSekgMqvDH84rr1wAQtD/w5tZNYF2t98="

#stripe keys
STRIPE_API_KEY = "sk_test_51PMO17JN30524Go3dYjmpXiFwJL2OBrAjEUC54SOs5I4uuqQDBRkcdIf2LNch0UfTrZr0nVdwmuioh7ooPYAwRSn00eA9C3DXu"

#fast2sms service api url
DEV_API_URL = "https://www.fast2sms.com/dev/bulkV2"

#razor pay keys
RAZORPAY_API_KEY="rzp_test_qg4DCxSRKLNp3Q"
RAZORPAY_WEBHOOK_SECREATE="kdpXCVsITjJprAJJhuJhu3bc"
RAZORPAY_PAYOUT_API_URL = 'https://api.razorpay.com/v1/payouts'

#admin access email id's
ADMIN_ACCESS_EMAILS = ["gunasekhar.neeluri@maangtechnologies.com","admin@maangtechnologies.com","info@maangtechnologies.com","linga@maangtechnologies.com","sumanth.yaddanapudi@maangtechnologies.com"]

#cashfreee payment gateway keys
CASHFREE_API_KEY ='TEST10278331d470c2f8d1f7abe1c2da13387201'
CASHFREE_WEBHOOK_SECREATE='cfsk_ma_test_c5546447dc1a3f86fa016d40c5e4a236_4af8c9a3'
CASHFREE_CLIENT_ID = 'CF10278331CQPH95NPU07S7391HHH0'
CASHFREE_CLIENT_SECREATE = 'cfsk_ma_test_a7a72dad8000f569c1728e74ed4fae3f_d1648426'
CASHFREE_BENEFICIARY_API_URL = "https://sandbox.cashfree.com/payout/beneficiary"
CASHFREE_TRANSFER_API_URL = "https://sandbox.cashfree.com/payout/transfers"

#fast2sms service api url
DEV_API_URL = "https://www.fast2sms.com/dev/bulkV2"

#Gamil app passwords
SMTP_EMAIL = 'no-reply@maangtechnologies.com'
SMTP_PASSWORD = 'fzyc wkyk vfgk myvx'

#admin access email id's
ADMIN_ACCESS_EMAILS = ["sumanth.yaddanapudi@maangtechnologies.com","gunasekhar.neeluri@maangtechnologies.com","admin@maangtechnologies.com","info@maangtechnologies.com","linga@maangtechnologies.com"]

POSTGRES_DB_USERNAME = 'maang'
POSTGRES_DB_PSWD = 'maang@123'
encoded_password = quote(POSTGRES_DB_PSWD, safe='')
POSTGRES_DB_URL = '178.16.139.18:5432'
POSTGRES_DB_NAME = 'dealmerge-dev'

# POSTGRES_DATABASE_URL = 'sqlite:///./spp.db'
POSTGRES_DATABASE_URL = f'postgresql://{POSTGRES_DB_USERNAME}:{encoded_password}@{POSTGRES_DB_URL}/{POSTGRES_DB_NAME}'
