from apscheduler.schedulers.background import BackgroundScheduler
# from sqlalchemy.orm import Session
from models import Session
from models.otp_counters import OtpCounters
from models.users import User

scheduler = None

def check_signup_otp_count_and_change_otp_count():
    session = Session()

    query = session.query(OtpCounters).all()

    for otp_model  in query:
        phone_number_id = otp_model.is_signup_count_exceeded()
        id_ = otp_model.is_forgot_password_count_exceeded()
        activation_id = otp_model.is_account_activation_count_exceeded()

        if phone_number_id :
            print(phone_number_id)
            db_ = session.query(OtpCounters).filter(OtpCounters.id == phone_number_id).first()
            db_.signup_otp_count = 0
            session.commit()

        if id_ :
            db_ = session.query(OtpCounters).filter(OtpCounters.id == id_).first()
            db_.forgot_password_otp_count = 0
            session.commit()

        if activation_id :
            db_ = session.query(OtpCounters).filter(OtpCounters.id == activation_id).first()
            db_.account_reactivation_otp_count = 0
            session.commit()

    session.close()

def start_scheduler():
    global scheduler
    scheduler = BackgroundScheduler()
    scheduler.add_job(check_signup_otp_count_and_change_otp_count, 'interval', hours=5)
    scheduler.start()

def stop_scheduler():
    global scheduler
    if scheduler:
        scheduler.shutdown()
