from infra import email_templates,utils
import re
from datetime import datetime
from fastapi import HTTPException,status

#models
from models import Session
from models.users import User

def convert_google_drive_link(link: str):
    file_id_match = re.search(r'd\/([a-zA-Z0-9_-]+)', link)

    if file_id_match:
        return f"https://drive.google.com/thumbnail?id={file_id_match.group(1)}&sz=w1000"

async def notification_for_password_reset(email,username):
    subject = "Your Password Has Been Successfully Reset"
    info1 = "We wanted to let you know that your password has been successfully reset"
    info2 = "If you did not request this change or if you have any concerns, please contact our support team immediately"
    html_content = email_templates.get_notify_template(username,info1,info2)

    await utils.send_notifications(email,subject,html_content)

async def notification_for_password_change(email,username):
    subject = "Your Password Has Been Successfully Updated"
    info1 = "We wanted to let you know that your password has been successfully updated."
    info2 = "If you did not request this change or if you have any concerns, please contact our support team immediately"
    html_content = email_templates.get_notify_template(username,info1,info2)

    await utils.send_notifications(email,subject,html_content)
