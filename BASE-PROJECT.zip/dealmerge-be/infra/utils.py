#fastapi
from fastapi import FastAPI,BackgroundTasks,APIRouter,Query,Depends,status, Request,HTTPException,Form,status,File,UploadFile
from typing import Annotated,Optional,List
from pydantic import BaseModel
from fastapi.responses import JSONResponse
from datetime import datetime
from sqlalchemy import func

#single imports
import os,pytz,re,logging,json,secrets,string
from datetime import datetime

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

#models
from models import Session
from models.users import User

#other imports
import pandas as pd
from utilities import constants

#email imports
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def get_db():
    try:
        db = Session()
        yield db
    finally:
        db.close()

db_dependency = Annotated[Session, Depends(get_db)]


def get_user_details_by_id(id):
    try:

        db = Session()

        user = db.query(User).filter(User.is_active == True,User.id==id).first()

        return user

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

    finally:
        if db:
            db.close()

def generate_password(length=12):
    try:

        characters = string.ascii_letters + string.digits + string.punctuation
        password = ''.join(secrets.choice(characters) for _ in range(length))
        return password

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

def is_email_exists(email):
    db = Session()
    db_ = db.query(User).filter(func.lower(User.email) == func.lower(email)).first()
    if db_:
        return True
    return False

def is_phone_number_exists(phone_number):
    db = Session()
    db_ = db.query(User).filter(func.lower(User.phone_number) == func.lower(str(phone_number))).first()
    if db_:
        return True
    return False

def is_valid_date(date_string):

    formats = ["%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d","%Y/%m/%d"]
    for format_str in formats:
        try:
            datetime.strptime(date_string, format_str)

            temp = datetime.strptime(date_string, format_str)
            return temp.date()
        except ValueError as e:
            print(str(e))
    return False

async def send_notifications(email: str, subject: str,html_content, pdf_file_path: str = None):
    sender_email =  constants.SMTP_EMAIL
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    smtp_username = sender_email
    smtp_password = constants.SMTP_PASSWORD    # Replace with your actual SMTP password
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = email
    message["Subject"] = subject
    part = MIMEText(html_content,'html')
    message.attach(part)


    # Attach the PDF file if provided
    if pdf_file_path:
        with open(pdf_file_path, "rb") as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename="{pdf_file_path.split("/")[-1]}"')
            message.attach(part)


    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(smtp_username, smtp_password)
        server.sendmail(sender_email, email, message.as_string())
