def get_otp_template(username,otp,otp_purpose,otp_info):
    template= f"""<!DOCTYPE html>
                    <html lang="en">

                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>OTP Email</title>
                    </head>

                    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px 0; color: #333333;">
                        <table align="center" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; padding: 20px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 8px;">
                            <tr>
                                <td align="center" style="margin-bottom:22px;">
                                    <!-- Replace with your hosted image URL -->
                                    <img src="https://dev-resume-builder-be.maangtechnologies.com/images/maang_logo.png" alt="Your Image" width="94" height="40">
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 32px 0 38px 0; position: relative;">
                                    <!-- Replace with your hosted main image URL -->
                                    <img src="https://dev-resume-builder-be.maangtechnologies.com/images/template_image.png" alt="Main Image" width="584" height="156" style="display: block;">
                                    <!-- Replace with your hosted logo URL -->
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h1 style="color: #000; font-family: Inter, Arial, sans-serif; font-size: 24px; font-weight: 500; line-height: 32px; margin-bottom:32px;">Dear {username},</h1>
                                    <p style="color: #333; margin-bottom:32px;font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        {otp_info}.<br>
                                        Below is your <strong>OTP</strong> for {otp_purpose}.
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 20px 0;">
                                    <table cellspacing="15" cellpadding="0" border="0">
                                        <tr>
                                            <td align="center" style="width: 55px; height: 55px; background: rgba(7, 95, 236, 0.05); border-radius: 5px; color: #10241B; font-size: 24px; font-family: Inter, Arial, sans-serif; font-weight: 600;">
                                                {otp[0]}
                                            </td>
                                            <td align="center" style="width: 55px; height: 55px; background: rgba(7, 95, 236, 0.05); border-radius: 5px; color: #10241B; font-size: 24px; font-family: Inter, Arial, sans-serif; font-weight: 600;">
                                                {otp[1]}
                                            </td>
                                            <td align="center" style="width: 55px; height: 55px; background: rgba(7, 95, 236, 0.05); border-radius: 5px; color: #10241B; font-size: 24px; font-family: Inter, Arial, sans-serif; font-weight: 600;">
                                                {otp[2]}
                                            </td>
                                            <td align="center" style="width: 55px; height: 55px; background: rgba(7, 95, 236, 0.05); border-radius: 5px; color: #10241B; font-size: 24px; font-family: Inter, Arial, sans-serif; font-weight: 600;">
                                                {otp[3]}
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <p style="color: #333; margin-bottom:32px;font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        If you did not request this change or if you have any concerns, please contact our support team immediately.
                                    </p>
                                    <p style="color: #333; margin-bottom:32px;font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        OTP will expire in <strong>5 minutes</strong>.
                                    </p>
                                    <p style="color: #333; font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        Best Regards,<br>
                                        <span style="color: #075FEC;">Maang Team.</span>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 16 0 8px 0;">
                                    <div style="border-top: 1px solid #D9D9D9; margin:13px 0 10px 0; border-bottom: 1px solid #D9D9D9; height: 64px; width: 100%;">
                                        <a href="https://www.facebook.com/people/Maang_Technologies/100094655003149/" target="_blank" style="text-decoration: none;">
                                            <img src="https://dev-resume-builder-be.maangtechnologies.com/images/facebook.png" style="margin-right: 10px;margin-top:18px" width="32px" alt="Facebook" class="social-icon">
                                        </a>
                                        <a href="https://www.instagram.com/maang_technologies/ target="_blank" style="text-decoration: none;">
                                            <img src="https://dev-resume-builder-be.maangtechnologies.com/images/instagram.png" style="margin-right: 10px;" width="32px" alt="Instagram" class="social-icon">
                                        </a>
                                        <a href="https://in.linkedin.com/company/maang-technologies-private-limited" target="_blank" style="text-decoration: none;">
                                            <img src="https://dev-resume-builder-be.maangtechnologies.com/images/linkedin.png" style="margin-right: 10px;" width="32px" alt="LinkedIn" class="social-icon">
                                        </a>
                                    </div>
                                    <div style="color: black; font-size: 10px; font-family: Inter, Arial, sans-serif; font-weight: 400; word-wrap: break-word; margin: 16px 0 32px 0;">
                                        © 2024 <a href="https://maangtechnologies.com/" target="_blank" style="text-decoration: none;color:black;"> MAANG TECHNOLOGIES </a>. All rights reserved.
                                    </div>
                                    <div style="color: black; font-size: 10px; width:476px;height:36px;font-family: Inter, Arial, sans-serif; font-weight: 400; word-wrap: break-word; margin: 0 0 10px 0 ;">
                                        You are receiving this mail because you registered to join the MAANG platform as a user or a creator. This also shows that you agree to our Terms of use and Privacy Policies. If you no longer want to receive mails from use, click the unsubscribe link below to unsubscribe.
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div style="text-align: center; font-size: 10px; color: #333333; font-family: Euclid Circular A, Arial, sans-serif; margin: 8px 0 20px 0;">
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Privacy policy</a></div>
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Terms of service</a></div>
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Help center</a></div>
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Unsubscribe</a></div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </body>

                    </html>
                    """
    return template

def get_notify_template(username,notify_info1,notify_info2):
    template= f"""<!DOCTYPE html>
                    <html lang="en">

                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>OTP Email</title>
                    </head>

                    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px 0; color: #333333;">
                        <table align="center" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; padding: 20px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 8px;">
                            <tr>
                                <td align="center" style="margin-bottom:22px;">
                                    <!-- Replace with your hosted image URL -->
                                    <img src="https://dev-resume-builder-be.maangtechnologies.com/images/maang_logo.png" alt="Your Image" width="94" height="40">
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 32px 0 38px 0; position: relative;">
                                    <!-- Replace with your hosted main image URL -->
                                    <img src="https://dev-resume-builder-be.maangtechnologies.com/images/template_image.png" alt="Main Image" width="584" height="156" style="display: block;">
                                    <!-- Replace with your hosted logo URL -->
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h1 style="color: #000; font-family: Inter, Arial, sans-serif; font-size: 24px; font-weight: 500; line-height: 32px; margin-bottom:32px;">Dear {username},</h1>
                                    <p style="color: #333; margin-bottom:12px;font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        {notify_info1}.
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <p style="color: #333; margin-bottom:12px;font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        {notify_info2}
                                    </p>
                                    <p style="color: #333; font-family: Inter, Arial, sans-serif; font-size: 14px; line-height: 22px;">
                                        Best Regards,<br>
                                        <span style="color: #075FEC;">Maang Team.</span>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 16 0 8px 0;">
                                    <div style="border-top: 1px solid #D9D9D9; margin:13px 0 10px 0; border-bottom: 1px solid #D9D9D9; height: 64px; width: 100%;">
                                        <a href="https://www.facebook.com/people/Maang_Technologies/100094655003149/" target="_blank" style="text-decoration: none;">
                                            <img src="https://dev-resume-builder-be.maangtechnologies.com/images/facebook.png" style="margin-right: 10px;margin-top:18px" width="32px" alt="Facebook" class="social-icon">
                                        </a>
                                        <a href="https://www.instagram.com/maang_technologies/" target="_blank" style="text-decoration: none;">
                                            <img src="https://dev-resume-builder-be.maangtechnologies.com/images/instagram.png" style="margin-right: 10px;" width="32px" alt="Instagram" class="social-icon">
                                        </a>
                                        <a href="https://in.linkedin.com/company/maang-technologies-private-limited" target="_blank" style="text-decoration: none;">
                                            <img src="https://dev-resume-builder-be.maangtechnologies.com/images/linkedin.png" style="margin-right: 10px;" width="32px" alt="LinkedIn" class="social-icon">
                                        </a>
                                    </div>
                                    <div style="color: black; font-size: 10px; font-family: Inter, Arial, sans-serif; font-weight: 400; word-wrap: break-word; margin: 16px 0 32px 0;">
                                        © 2024 <a href="https://maangtechnologies.com/" target="_blank" style="text-decoration: none;color:black;"> MAANG TECHNOLOGIES </a>. All rights reserved.
                                    </div>
                                    <div style="color: black; font-size: 10px; width:476px;height:36px;font-family: Inter, Arial, sans-serif; font-weight: 400; word-wrap: break-word; margin: 0 0 10px 0 ;">
                                        You are receiving this mail because you registered to join the MAANG platform as a user or a creator. This also shows that you agree to our Terms of use and Privacy Policies. If you no longer want to receive mails from use, click the unsubscribe link below to unsubscribe.
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div style="text-align: center; font-size: 10px; color: #333333; font-family: Euclid Circular A, Arial, sans-serif; margin: 8px 0 20px 0;">
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Privacy policy</a></div>
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Terms of service</a></div>
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Help center</a></div>
                                        <div style="display: inline-block; margin: 0 5px;"><a href="#" style="color: #333;">Unsubscribe</a></div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </body>

                    </html>
        """
    return template
